import boto3
def lambda_handler(event, context):
    """
    Lambda function for the course
    """
    print("Print Event ", event)